/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2021 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include <stdio.h>
#include "pin_mux.h"
#include "clock_config.h"
#include "MK64F12.h"
#include "fsl_debug_console.h"
#include "fsl_flexcan.h"
#include "clock_config.h"
#include "board.h"
#include "PIT.h"
#include "NVIC.h"
#include "fsl_adc16.h"

#define DEMO_ADC16_CHANNEL_GROUP 0U
adc16_channel_config_t adc16ChannelConfigStruct;

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_CAN            CAN0
#define EXAMPLE_CAN_CLK_SOURCE (kFLEXCAN_ClkSrc1)
#define EXAMPLE_CAN_CLK_FREQ   CLOCK_GetFreq(kCLOCK_BusClk)
/* Set USE_IMPROVED_TIMING_CONFIG macro to use api to calculates the improved CAN / CAN FD timing values. */
#define USE_IMPROVED_TIMING_CONFIG (0U)
#define RX_BATTERY_TIME_BUFFER_NUM (9) //mailbox 9
#define RX_ACTUATOR_BUFFER_NUM (7) //mailbox 7
#define TX_KPA_BUFFER_NUM      (8)
#define TX_BATTERY_LEVEL_BUFFER_NUM  (6)
#define DLC                        (8)
#define SYSTEM_CLOCK (CLOCK_GetCoreSysClkFreq())
#define DELAY_PIT0 (5.0F)	//Keep alive
#define DELAY_PIT1 (5.0F)	//Battery report
/* Fix MISRA_C-2012 Rule 17.7. */
#define LOG_INFO (void)PRINTF
/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile bool txComplete100 = false;
volatile bool txComplete25 = false;
volatile bool rxComplete55 = false;
volatile bool rxComplete80 = false;
uint8_t g_REPORT_TIME = 0;
uint8_t g_ACTUATOR_STATUS = 1;
flexcan_handle_t flexcanHandle;
flexcan_mb_transfer_t txXfer100,txXfer25, rxXfer55 ,rxXfer80;

flexcan_frame_t txFrame100,txFrame25, rxFrame55, rxFrame80;

enum{
	T_5s,
	T_10s,
	T_15s,
}Tiempo;
/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief FlexCAN Call Back function
 */
static FLEXCAN_CALLBACK(flexcan_callback)
{
    switch (status)
    {
        /* Process FlexCAN Rx event. */
        case kStatus_FLEXCAN_RxIdle:
            if (RX_BATTERY_TIME_BUFFER_NUM == result)
            {
                rxComplete55 = true;
            }
            if (RX_ACTUATOR_BUFFER_NUM == result)
            {
                rxComplete80 = true;
            }
            break;

        /* Process FlexCAN Tx event. */
        case kStatus_FLEXCAN_TxIdle:
            if (TX_KPA_BUFFER_NUM == result)
            {
                txComplete100 = true;
            }
            if (TX_BATTERY_LEVEL_BUFFER_NUM == result)
            {
                txComplete25 = true;
            }
            break;

        default:
            break;
    }
}

/*!
 * @brief Main function
 */
void RGB_init(void){
	SIM->SCGC5 = 0x400;
	/**RGB pins as GPIO*/
	PORTB->PCR[22] |= 0x00000100;
	PORTB->PCR[21] |= 0x00000100;
	/**Assigns a safe value to RGB pins*/
	GPIOB->PSOR|= 1<<22;
	GPIOB->PSOR |= 1<<21;
	/**RGB pins as output*/
	GPIOB->PDDR |= 1<<22;
	GPIOB->PDDR |= 1<<21;
}
void PIT_init(void){
	PIT_clock_gating();
	PIT_enable();
	PIT_enable_interrupt(PIT_0);
	PIT_enable_interrupt(PIT_1);
	PIT_delay(PIT_0, SYSTEM_CLOCK, DELAY_PIT0);//Keep alive
	PIT_delay(PIT_1, SYSTEM_CLOCK, DELAY_PIT1);//Battery report
	PIT_CH_enable(PIT_0);
}
void adc_init(){


	/* Port B Clock Gate Control: Clock enabled */
	CLOCK_EnableClock(kCLOCK_PortB);
	/* PORTB2 (pin 55) is configured as ADC0_SE12 */
	PORT_SetPinMux(PORTB,  2U, kPORT_PinDisabledOrAnalog);

	/*** configure  AD00  periph   */
	adc16_config_t adc16ConfigStruct;

	ADC16_GetDefaultConfig(&adc16ConfigStruct);

	 adc16ConfigStruct.resolution =  kADC16_Resolution16Bit ;
	ADC16_Init(ADC0, &adc16ConfigStruct);
	ADC16_EnableHardwareTrigger(ADC0, false); /* Make sure the software trigger is used. */

	if (kStatus_Success == ADC16_DoAutoCalibration(ADC0))
	{
		PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
	}
	else
	{
		PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
	}


	PRINTF("ADC Full Range: %d\r\n", 65535);

	adc16ChannelConfigStruct.channelNumber                        =  12 ;// canal  12
	adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
	adc16ChannelConfigStruct.enableDifferentialConversion = false;

	PRINTF("ADC Full Range: %d\r\n", 65535);

}

// triger  single ADC  conversion
uint16_t  adc_read(void ){


	ADC16_SetChannelConfig(ADC0, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
	while (0U == (kADC16_ChannelConversionDoneFlag &
			ADC16_GetChannelStatusFlags(ADC0, DEMO_ADC16_CHANNEL_GROUP)))
	{
	}

	return   ADC16_GetChannelConversionValue(ADC0, DEMO_ADC16_CHANNEL_GROUP);
}
int main(void)
{
	uint16_t ADC_VALUE = 0;
	char *TIME[4] = {"5s","10s","15s"};
	char *STATUS[3] = {"ON","OFF"};
    flexcan_config_t flexcanConfig;
    flexcan_rx_mb_config_t mbConfig55;
    flexcan_rx_mb_config_t mbConfig80;

    /* Initialize board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();
    adc_init();
    RGB_init();
	NVIC_enable_interrupt_and_priotity(PIT_CH0_IRQ, PRIORITY_9);//Keep Alive
	NVIC_enable_interrupt_and_priotity(PIT_CH1_IRQ, PRIORITY_10);//Battery report
	NVIC_global_enable_interrupts;
    PIT_init();
    LOG_INFO("\r\n==FlexCAN loopback example -- Start.==\r\n\r\n");

    /* Init FlexCAN module. */
    /*
     * flexcanConfig.clkSrc                 = kFLEXCAN_ClkSrc0;
     * flexcanConfig.baudRate               = 1000000U;
     * flexcanConfig.baudRateFD             = 2000000U;
     * flexcanConfig.maxMbNum               = 16;
     * flexcanConfig.enableLoopBack         = false;
     * flexcanConfig.enableSelfWakeup       = false;
     * flexcanConfig.enableIndividMask      = false;
     * flexcanConfig.disableSelfReception   = false;
     * flexcanConfig.enableListenOnlyMode   = false;
     * flexcanConfig.enableDoze             = false;
     */
    FLEXCAN_GetDefaultConfig(&flexcanConfig);
    flexcanConfig.clkSrc = EXAMPLE_CAN_CLK_SOURCE;
    //flexcanConfig.enableLoopBack = true;
    flexcanConfig.baudRate               = 125000U;
    FLEXCAN_Init(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ);

    /* Setup Rx Message Buffer (DEFAULT). */
    mbConfig55.format = kFLEXCAN_FrameFormatStandard;
    mbConfig55.type   = kFLEXCAN_FrameTypeData;
    mbConfig55.id     = FLEXCAN_ID_STD(0x55);
    /* Setup Rx Message Buffer USER. */
    mbConfig80.format = kFLEXCAN_FrameFormatStandard;
    mbConfig80.type   = kFLEXCAN_FrameTypeData;
    mbConfig80.id     = FLEXCAN_ID_STD(0x80);

    //Mailbox Frecuencia de reporte de bateria
    FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_BATTERY_TIME_BUFFER_NUM, &mbConfig55, true);
    //Mailbox actuador
    FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, 7, &mbConfig80, true);


/* Setup Tx Message Buffer. */

    FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_KPA_BUFFER_NUM, true);
    FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_BATTERY_LEVEL_BUFFER_NUM, true);


    /* Create FlexCAN handle structure and set call back function. */
    FLEXCAN_TransferCreateHandle(EXAMPLE_CAN, &flexcanHandle, flexcan_callback, NULL);

    /* Start receive data through Rx Message Buffer. */
    rxXfer55.mbIdx = (uint8_t)RX_BATTERY_TIME_BUFFER_NUM;
    rxXfer55.frame = &rxFrame55;

    rxXfer80.mbIdx = (uint8_t)RX_ACTUATOR_BUFFER_NUM;
    rxXfer80.frame = &rxFrame80;

    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer55);
    (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer80);


    /* Prepare Tx Frame for sending Keep Alive. */
    txFrame100.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
    txFrame100.type   = (uint8_t)kFLEXCAN_FrameTypeData;
    txFrame100.id     = FLEXCAN_ID_STD(0x100);
    txFrame100.length = (uint8_t)DLC;
    /* Prepare Tx Frame for sending Battery Level. */
    txFrame25.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
    txFrame25.type   = (uint8_t)kFLEXCAN_FrameTypeData;
    txFrame25.id     = FLEXCAN_ID_STD(0x25);
    txFrame25.length = (uint8_t)DLC;

    //uint16_t ADC_VALUE = 0xFFAA;//3.3v



    LOG_INFO("Send message from MB%d to MB%d\r\n", TX_KPA_BUFFER_NUM, RX_BATTERY_TIME_BUFFER_NUM);

    LOG_INFO("tx word0 = 0x%x\r\n", txFrame100.dataWord0);
    LOG_INFO("tx word1 = 0x%x\r\n", txFrame100.dataWord1);


    /* Send data through Tx Message Buffer. */
    txXfer100.mbIdx = (uint8_t)TX_KPA_BUFFER_NUM;
    txXfer100.frame = &txFrame100;
    txXfer25.mbIdx = (uint8_t)TX_BATTERY_LEVEL_BUFFER_NUM;
    txXfer25.frame = &txFrame25;
    //Enviar Keep Alive al iniciar el programa
    //(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer100);

    for(;;){
    /* Waiting for Rx Message. */
    do{
        while ((!rxComplete55) && (!rxComplete80))
        {
        	if(true == PIT0_get_interrupt_flag_status() ){
        		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer100);
        	    PIT0_clear_interrupt_flag();
        	    PIT_CH_enable(PIT_1);
        	    txComplete25 = 0;
        	}
        	if(true == PIT1_get_interrupt_flag_status()){
        		ADC_VALUE  = adc_read();
        		txFrame25.dataWord0 = CAN_WORD0_DATA_BYTE_3((uint8_t)ADC_VALUE & 0xFF) | CAN_WORD0_DATA_BYTE_2((uint8_t)((ADC_VALUE&0xFF00)>>8));
        	    (void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer25);
        	    PIT1_clear_interrupt_flag();
        	    txComplete100 = 0;
        	}

        };
        //Recibido nueva frecuencia de reporte de bateria
        if(true == rxComplete55){
        	g_REPORT_TIME = rxFrame55.dataByte0 & 0x03;
            LOG_INFO("\r\nBattery report time changed to: %s\r\n", TIME[g_REPORT_TIME]);
            LOG_INFO("rx word0 = 0x%x\r\n", rxFrame55.dataWord0);
            LOG_INFO("rx word1 = 0x%x\r\n", rxFrame55.dataWord1);
            (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer55);

            if(T_5s == g_REPORT_TIME){
                PIT_delay(PIT_1, SYSTEM_CLOCK, 5.0);//Battery report
            }else if(T_10s == g_REPORT_TIME){
                PIT_delay(PIT_1, SYSTEM_CLOCK, 10.0);//Battery report
            }else if(T_15s == g_REPORT_TIME){
                PIT_delay(PIT_1, SYSTEM_CLOCK, 15.0);//Battery report
            }

        }
        //Recibido comando de actuador
        if(true == rxComplete80){
        	g_ACTUATOR_STATUS = rxFrame80.dataByte0 & 0x01;
            LOG_INFO("\r\nLED STATUS: %s\r\n", STATUS[g_ACTUATOR_STATUS]);
            LOG_INFO("rx word0 = 0x%x\r\n", rxFrame80.dataWord0);
            LOG_INFO("rx word1 = 0x%x\r\n", rxFrame80.dataWord1);
            GPIOB->PDOR  = g_ACTUATOR_STATUS<<21;// BLUE LED
            (void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer80);
        }

    }while(rxComplete55==0 && rxComplete80==0);
    rxComplete55 = 0;
    rxComplete80 = 0;
    }


}
