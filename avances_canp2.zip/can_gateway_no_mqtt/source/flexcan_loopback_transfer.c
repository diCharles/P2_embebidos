/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2021 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "fsl_flexcan.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "FreeRTOS.h"
#include "task.h"


#include "FIFO.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_CAN            CAN0
#define EXAMPLE_CAN_CLK_SOURCE (kFLEXCAN_ClkSrc1)
#define EXAMPLE_CAN_CLK_FREQ   CLOCK_GetFreq(kCLOCK_BusClk)
/* Set USE_IMPROVED_TIMING_CONFIG macro to use api to calculates the improved CAN / CAN FD timing values. */
#define USE_IMPROVED_TIMING_CONFIG (0U)
#define RX_KPA_BUFFER_NUM      (9)

#define RX_BAT_BUFFER_NUM       (7)

#define TX_MESSAGE_BUFFER_NUM      (8)
#define DLC                        (8)

#define KEEP_ALIVE_ID 0x100
#define NIVEL_BATERIA_ID 0x25


/* Fix MISRA_C-2012 Rule 17.7. */
#define LOG_INFO (void)PRINTF
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void CAN_Rx_Task(void* Args);
void CAN_Tx_Task(void* Args);
void CAN_Control_Task(void* Args);

/*******************************************************************************
 * Variables
 ******************************************************************************/
typedef struct{
	uint32_t ID;
	uint32_t dataword0;
	uint32_t dataword1;
}CAN_rx_message_t;

volatile bool txComplete = false;

volatile bool rx_Complete_kpa = false;
volatile bool rx_Complete_bat = false;

volatile bool g_can_kpa_arrived ;
volatile bool g_can_bat_arrived ;

flexcan_handle_t flexcanHandle;
flexcan_mb_transfer_t txXfer, rxXfer_kpa , rxXfer_bat;
flexcan_frame_t txFrame, rxFrame_kpa , rxFrame_bat;


flexcan_rx_mb_config_t mbConfig_kpa ;
flexcan_rx_mb_config_t mbConfig_batery ;



CAN_rx_message_t can_rx_keep_alive ;
CAN_rx_message_t can_rx_nivel_bateria ;

void print_CAN_rx_message( CAN_rx_message_t can_message);

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief FlexCAN Call Back function
 */
static FLEXCAN_CALLBACK(flexcan_callback)
								{
	switch (status)
	{
	/* Process FlexCAN Rx event. */
	case kStatus_FLEXCAN_RxIdle:
		if (RX_KPA_BUFFER_NUM == result)
		{
			rx_Complete_kpa = true;
		}
		if (RX_BAT_BUFFER_NUM == result)
		{
			rx_Complete_bat = true;
		}
		break;

		/* Process FlexCAN Tx event. */
	case kStatus_FLEXCAN_TxIdle:
		if (TX_MESSAGE_BUFFER_NUM == result)
		{
			txComplete = true;
		}
		break;

	default:
		break;
	}
								}

/*!
 * @brief Main function
 */
int main(void)
{
	flexcan_config_t flexcanConfig;

	/* Initialize board hardware. */
	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitDebugConsole();

	if(xTaskCreate(
			CAN_Rx_Task, /* Pointer to the function that implements the task. */
			"CAN_Rx_Task", /* Text name given to the task. */
			(configMINIMAL_STACK_SIZE*10), /* The size of the stack that should be created for the task.
                                        This is defined in words, not bytes. */
			NULL,/* A reference to xParameters is used as the task parameter.
              This is cast to a void * to prevent compiler warnings. */
			(configMAX_PRIORITIES-4), /* The priority to assign to the newly created task. */
			NULL /* The handle to the task being created will be placed in
              xHandle. */
	) != pdPASS )
	{
		LOG_INFO("Failing to create CAN_Rx_Task");
		while(1);
	}


	if(xTaskCreate(
			CAN_Tx_Task, /* Pointer to the function that implements the task. */
			"CAN_Rx_Task", /* Text name given to the task. */
			(configMINIMAL_STACK_SIZE*10), /* The size of the stack that should be created for the task.
                                        This is defined in words, not bytes. */
			NULL,/* A reference to xParameters is used as the task parameter.
              This is cast to a void * to prevent compiler warnings. */
			(configMAX_PRIORITIES-3), /* The priority to assign to the newly created task. */
			NULL /* The handle to the task being created will be placed in
              xHandle. */
	) != pdPASS )
	{
		LOG_INFO("Failing to create CAN_Tx_Task");
		while(1);
	}

	if(xTaskCreate(
			CAN_Control_Task, /* Pointer to the function that implements the task. */
			"CAN_Control_Task", /* Text name given to the task. */
			(configMINIMAL_STACK_SIZE*5), /* The size of the stack that should be created for the task.
                                              This is defined in words, not bytes. */
			NULL,/* A reference to xParameters is used as the task parameter.
                    This is cast to a void * to prevent compiler warnings. */
			(configMAX_PRIORITIES-4), /* The priority to assign to the newly created task. */
			NULL /* The handle to the task being created will be placed in
                    xHandle. */
	) != pdPASS )
	{
		LOG_INFO("Failing to create CAN_Control_Task");
		while(1);
	}



	LOG_INFO("\r\n==FlexCAN loopback example -- Start.==\r\n\r\n");

	FLEXCAN_GetDefaultConfig(&flexcanConfig);

#if defined(EXAMPLE_CAN_CLK_SOURCE)
	flexcanConfig.clkSrc = EXAMPLE_CAN_CLK_SOURCE;
#endif

	flexcanConfig.enableLoopBack = false;
	flexcanConfig.baudRate               = 125000U;

	FLEXCAN_Init(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ);

	/* Create FlexCAN handle structure and set call back function. */
	FLEXCAN_TransferCreateHandle(EXAMPLE_CAN, &flexcanHandle, flexcan_callback, NULL);


	/** do FIFO init of  3 KB */
	Init_FIFO( 1024*3);


	/* Start the scheduler. */
	vTaskStartScheduler();
}


void CAN_Rx_Task(void* Args){
	/* Setup Rx Message Buffer. */
	mbConfig_kpa.format = kFLEXCAN_FrameFormatStandard;
	mbConfig_kpa.type   = kFLEXCAN_FrameTypeData;
	mbConfig_kpa.id     = FLEXCAN_ID_STD(KEEP_ALIVE_ID);

	mbConfig_batery.format = kFLEXCAN_FrameFormatStandard;
	mbConfig_batery.type   = kFLEXCAN_FrameTypeData;
	mbConfig_batery.id     = FLEXCAN_ID_STD(NIVEL_BATERIA_ID);


	FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_KPA_BUFFER_NUM, &mbConfig_kpa, true);
	FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_BAT_BUFFER_NUM, &mbConfig_batery, true);

	/* Start receive data through Rx Message Buffer. */
	rxXfer_kpa.mbIdx = (uint8_t)RX_KPA_BUFFER_NUM;
	rxXfer_kpa.frame = &rxFrame_kpa;


	rxXfer_bat.mbIdx = (uint8_t)RX_BAT_BUFFER_NUM;
	rxXfer_bat.frame = &rxFrame_bat;

	for(;;){
		(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_kpa);
		if(rx_Complete_kpa){

			g_can_kpa_arrived = 1 ;

			can_rx_keep_alive.ID = KEEP_ALIVE_ID  ;
			can_rx_keep_alive.dataword0 = rxFrame_kpa.dataWord0 ;
			can_rx_keep_alive.dataword1 = rxFrame_kpa.dataWord1 ;

			 Fifo_Push( (void *)(&can_rx_keep_alive), sizeof(can_rx_keep_alive));

			rx_Complete_kpa = false;
		}

		(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_bat);
		if(rx_Complete_bat){

			g_can_bat_arrived = 1 ;

			can_rx_nivel_bateria.ID = NIVEL_BATERIA_ID ;
			can_rx_nivel_bateria.dataword0 = rxFrame_bat.dataWord0 ;
			can_rx_nivel_bateria.dataword1 = rxFrame_bat.dataWord1 ;

			Fifo_Push( (void *)(&can_rx_nivel_bateria), sizeof(can_rx_nivel_bateria));

			g_can_bat_arrived = false;

			rx_Complete_bat = false ;
		}
	}
}




void CAN_Tx_Task(void* Args){
	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 2000 );
	xLastWakeTime = xTaskGetTickCount();

	/* Setup Tx Message Buffer. */
	FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_MESSAGE_BUFFER_NUM, true);

	/* Prepare Tx Frame for sending. */
	txFrame.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
	txFrame.type   = (uint8_t)kFLEXCAN_FrameTypeData;
	txFrame.id     = FLEXCAN_ID_STD(0x123);
	txFrame.length = (uint8_t)DLC;

	txXfer.mbIdx = (uint8_t)TX_MESSAGE_BUFFER_NUM;
	txXfer.frame = &txFrame;

	txFrame.dataWord0 = CAN_WORD0_DATA_BYTE_0(0x11) | CAN_WORD0_DATA_BYTE_1(0x22) | CAN_WORD0_DATA_BYTE_2(0x33) |
			CAN_WORD0_DATA_BYTE_3(0x44);
	txFrame.dataWord1 = CAN_WORD1_DATA_BYTE_4(0x55) | CAN_WORD1_DATA_BYTE_5(0x66) | CAN_WORD1_DATA_BYTE_6(0x77) |
			CAN_WORD1_DATA_BYTE_7(0x88);

	for(;;){
		/* Send data through Tx Message Buffer. */
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer);
		if(txComplete){
			LOG_INFO("Send message from MB%d to MB%d\r\n", TX_MESSAGE_BUFFER_NUM, RX_KPA_BUFFER_NUM);
			LOG_INFO("tx word0 = 0x%x\r\n", txFrame.dataWord0);
			LOG_INFO("tx word1 = 0x%x\r\n", txFrame.dataWord1);


			txComplete = false;


		}else{}
		vTaskDelayUntil( &xLastWakeTime, xPeriod );
	}
}

void print_CAN_rx_message( CAN_rx_message_t can_message)
{

	LOG_INFO("\r\n");
	if( KEEP_ALIVE_ID == can_message.ID)
	{
		LOG_INFO(" KeepAlive ID = 0x%x\r\n", can_message.ID);
	}
	if( 0x25 == can_message.ID)
	{
		LOG_INFO(" Nivel de bateria. ID = 0x%x\r\n", can_message.ID);
	}


	LOG_INFO("	tx word1 = 0x%x\r\n", can_message.dataword0);
	LOG_INFO("	tx word1 = 0x%x\r\n", can_message.dataword1);

}


/**it will be the bridge between CAN  and MQTT layers */


void CAN_Control_Task(void* Args){

	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 2000 );
	xLastWakeTime = xTaskGetTickCount();

	CAN_rx_message_t any_rx_can_message ;


	// constantly poll CAN status flas
	for(;;)
	{

		if( 0 != Get_Elements_Count() )
		{
		 Fifo_Pop(  (void * )(& any_rx_can_message), sizeof (any_rx_can_message) );
		 print_CAN_rx_message(any_rx_can_message );

		}
/**
		if(true   == g_can_kpa_arrived)
		{
			print_CAN_rx_message( can_rx_keep_alive);
			g_can_kpa_arrived =  false ;
		}


		if(true   == g_can_bat_arrived)
		{
			print_CAN_rx_message( can_rx_nivel_bateria);
			g_can_bat_arrived = false ;
		}
		vTaskDelayUntil( &xLastWakeTime, xPeriod );
		*/
	}
}


