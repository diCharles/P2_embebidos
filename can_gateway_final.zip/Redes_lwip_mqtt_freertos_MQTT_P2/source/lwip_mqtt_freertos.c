/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 * All rights reserved.
 *
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "lwip/opt.h"

#if LWIP_IPV4 && LWIP_RAW && LWIP_NETCONN && LWIP_DHCP && LWIP_DNS

#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "fsl_phy.h"

#include "lwip/api.h"
#include "lwip/apps/mqtt.h"
#include "lwip/dhcp.h"
#include "lwip/netdb.h"
#include "lwip/netifapi.h"
#include "lwip/prot/dhcp.h"
#include "lwip/tcpip.h"
#include "lwip/timeouts.h"
#include "netif/ethernet.h"
#include "enet_ethernetif.h"
#include "lwip_mqtt_id.h"

#include "ctype.h"
#include "stdio.h"

#include "fsl_phyksz8081.h"
#include "fsl_enet_mdio.h"
#include "fsl_device_registers.h"
#include "fsl_flexcan.h"
#include "FIFO.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* MAC address configuration. */
#define configMAC_ADDR                     \
		{                                      \
	0x02, 0x12, 0x13, 0x10, 0x15, 0x11 \
		}

/* Address of PHY interface. */
#define EXAMPLE_PHY_ADDRESS BOARD_ENET0_PHY_ADDRESS

/* MDIO operations. */
#define EXAMPLE_MDIO_OPS enet_ops

/* PHY operations. */
#define EXAMPLE_PHY_OPS phyksz8081_ops

/* ENET clock frequency. */
#define EXAMPLE_CLOCK_FREQ CLOCK_GetFreq(kCLOCK_CoreSysClk)

/* GPIO pin configuration. */
#define BOARD_LED_GPIO       BOARD_LED_RED_GPIO
#define BOARD_LED_GPIO_PIN   BOARD_LED_RED_GPIO_PIN
#define BOARD_SW_GPIO        BOARD_SW3_GPIO
#define BOARD_SW_GPIO_PIN    BOARD_SW3_GPIO_PIN
#define BOARD_SW_PORT        BOARD_SW3_PORT
#define BOARD_SW_IRQ         BOARD_SW3_IRQ
#define BOARD_SW_IRQ_HANDLER BOARD_SW3_IRQ_HANDLER


#ifndef EXAMPLE_NETIF_INIT_FN
/*! @brief Network interface initialization function. */
#define EXAMPLE_NETIF_INIT_FN ethernetif0_init
#endif /* EXAMPLE_NETIF_INIT_FN */

/*! @brief MQTT server host name or IP address. */
#define EXAMPLE_MQTT_SERVER_HOST "io.adafruit.com"

/*! @brief MQTT server port number. */
#define EXAMPLE_MQTT_SERVER_PORT 1883

/*! @brief Stack size of the temporary lwIP initialization thread. */
#define INIT_THREAD_STACKSIZE 1024

/*! @brief Priority of the temporary lwIP initialization thread. */
#define INIT_THREAD_PRIO DEFAULT_THREAD_PRIO

/*! @brief Stack size of the temporary initialization thread. */
#define APP_THREAD_STACKSIZE 1024

/*! @brief Priority of the temporary initialization thread. */
#define APP_THREAD_PRIO DEFAULT_THREAD_PRIO

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

static void connect_to_mqtt(void *ctx);

/*******************************************************************************
 * Variables
 ******************************************************************************/

static mdio_handle_t mdioHandle = {.ops = &EXAMPLE_MDIO_OPS};
static phy_handle_t phyHandle   = {.phyAddr = EXAMPLE_PHY_ADDRESS, .mdioHandle = &mdioHandle, .ops = &EXAMPLE_PHY_OPS};

/*! @brief MQTT client data. */
static mqtt_client_t *mqtt_client;

/*! @brief MQTT client ID string. */
static char client_id[40];

/*! @brief MQTT client information. */
static const struct mqtt_connect_client_info_t mqtt_client_info = {
		.client_id   = (const char *)&client_id[0],
		.client_user = "RicardoRedes",
		.client_pass = "aio_fsIk87Eu4lJ42uhglEzdRV9GVUd7",
		.keep_alive  = 100,
		.will_topic  = NULL,
		.will_msg    = NULL,
		.will_qos    = 0,
		.will_retain = 0,
#if LWIP_ALTCP && LWIP_ALTCP_TLS
		.tls_config = NULL,
#endif
};

/*! @brief MQTT broker IP address. */
static ip_addr_t mqtt_addr;

/*! @brief Indicates connection to MQTT broker. */
static volatile bool connected = false;


#define EXAMPLE_CAN            CAN0
#define EXAMPLE_CAN_CLK_SOURCE (kFLEXCAN_ClkSrc1)
#define EXAMPLE_CAN_CLK_FREQ   CLOCK_GetFreq(kCLOCK_BusClk)
/* Set USE_IMPROVED_TIMING_CONFIG macro to use api to calculates the improved CAN / CAN FD timing values. */
#define USE_IMPROVED_TIMING_CONFIG (0U)


#define RX_KPA_BUFFER_NUM      (9)
#define RX_BAT_BUFFER_NUM       (7)

#define TX_BAT_REPORT_BUFFER_NUM      (8)
#define TX_ACTUADOR_BUFFER_NUM      (6)
#define DLC                        (8)

#define ACTUADOR_ID 0x80
#define FRECUENCIA_REPORTE_BATERIA_ID 0x55
#define KEEP_ALIVE_ID 0x100
#define NIVEL_BATERIA_ID 0x25


/* Fix MISRA_C-2012 Rule 17.7. */
#define LOG_INFO (void)PRINTF
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void CAN_Rx_Task(void* Args);
void CAN_Tx_Task(void* Args);
void CAN_Control_Task(void* Args);

/*******************************************************************************
 * Variables
 ******************************************************************************/
typedef struct{
	uint32_t ID;
	uint32_t dataword0;
	uint32_t dataword1;
}CAN_rx_message_t;

enum{
	T_5s,
	T_10s,
	T_15s,
}f_rep_bateria_e;

volatile bool txComplete_rep_bat = false;
volatile bool txComplete_actuador = false;

volatile bool rx_Complete_kpa = false;
volatile bool rx_Complete_bat = false;

volatile bool g_can_kpa_arrived ;
volatile bool g_can_bat_arrived ;

flexcan_handle_t flexcanHandle;
flexcan_mb_transfer_t txXfer_rep_bat,txXfer_act ,  rxXfer_kpa , rxXfer_bat;
flexcan_frame_t  txFrame_rep_bat,   txFrame_act, rxFrame_kpa , rxFrame_bat;


flexcan_rx_mb_config_t mbConfig_kpa ;
flexcan_rx_mb_config_t mbConfig_batery ;



CAN_rx_message_t can_rx_keep_alive ;
CAN_rx_message_t can_rx_nivel_bateria ;

void print_CAN_rx_message( CAN_rx_message_t can_message);



/*******************************************************************************
 * Code
 ******************************************************************************/




/*!
 * @brief Called when subscription request finishes.
 */
static void mqtt_topic_subscribed_cb(void *arg, err_t err)
{
	const char *topic = (const char *)arg;

	if (err == ERR_OK)
	{
		PRINTF("Subscribed to the topic \"%s\".\r\n", topic);
	}
	else
	{
		PRINTF("Failed to subscribe to the topic \"%s\": %d.\r\n", topic, err);
	}
}

/*!
 * @brief Called when there is a message on a subscribed topic.
 */
int EsComando(char *Comando,char *Const);
static void mqtt_incoming_publish_cb(void *arg, const char *topic, u32_t tot_len)
{
	LWIP_UNUSED_ARG(arg);

	PRINTF("Received %u bytes from the topic \"%s\": \"", tot_len, topic);


	//todo
}

/*!
 * @brief Called when recieved incoming published message fragment.
 */
static void mqtt_incoming_data_cb(void *arg, const u8_t *data, u16_t len, u8_t flags)
{
	int i;
	char ON_LED[]={"ON_LED"};
	char OFF_LED[]={"OFF_LED"};
	char Five_seg[]={"5"};
	char Ten_seg[]={"10"};
	char Ten5_seg[]={"15"};
	uint8_t freq_reporte_bat = 0x00;
	LWIP_UNUSED_ARG(arg);

	char Recibido[7]={"0"};
	for (i = 0; i < len; i++)
	{
		if (isprint(data[i]))
		{

			PRINTF("%c", (char)data[i]);
			Recibido[i]= (char)data[i];

		}
		else
		{
			PRINTF("\\x%02x", data[i]);
		}
	}

	//txFrame_rep_bat.dataWord0 = CAN_WORD0_DATA_BYTE_0(freq_reporte_bat);

	if(EsComando(Recibido,Five_seg)){
		//uint8_t dummy_read = tcpip_callback(publish_message(NULL), NULL);
		txFrame_rep_bat.dataWord0 = CAN_WORD0_DATA_BYTE_0(T_5s);
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer_rep_bat);
	}else if(EsComando(Recibido,Ten_seg)){
		txFrame_rep_bat.dataWord0 = CAN_WORD0_DATA_BYTE_0(T_10s);
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer_rep_bat);

	}else if(EsComando(Recibido,Ten5_seg)){
		txFrame_rep_bat.dataWord0 = CAN_WORD0_DATA_BYTE_0(T_15s);
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer_rep_bat);

	}

	//txFrame_act.dataWord0 = CAN_WORD0_DATA_BYTE_0(0x00);
	if(EsComando(Recibido,ON_LED)){
		txFrame_act.dataWord0 = CAN_WORD0_DATA_BYTE_0(0x00);
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer_act);
		//GPIOB->PCOR |= 1<<22;
	}
	if(EsComando(Recibido,OFF_LED)){
		txFrame_act.dataWord0 = CAN_WORD0_DATA_BYTE_0(0x01);
		(void)FLEXCAN_TransferSendNonBlocking(EXAMPLE_CAN, &flexcanHandle, &txXfer_act);
		//GPIOB->PSOR |= 1<<22;
	}

	if (flags & MQTT_DATA_FLAG_LAST)
	{
		PRINTF("\"\r\n");
	}
	can_rx_thread();
}

/*!
 * @brief Subscribe to MQTT topics.
 */
static void mqtt_subscribe_topics(mqtt_client_t *client)
{
	static const char *topics[] = {"RicardoRedes/feeds/Subscribe_actuador"};//,"RicardoRedes/feeds/Subscribe_BTime"};
	int qos[]                   = {0};
	err_t err;
	int i;

	mqtt_set_inpub_callback(client, mqtt_incoming_publish_cb, mqtt_incoming_data_cb,
			LWIP_CONST_CAST(void *, &mqtt_client_info));

	for (i = 0; i < ARRAY_SIZE(topics); i++)
	{
		err = mqtt_subscribe(client, topics[i], qos[i], mqtt_topic_subscribed_cb, LWIP_CONST_CAST(void *, topics[i]));

		if (err == ERR_OK)
		{
			PRINTF("Subscribing to the topic \"%s\" with QoS %d...\r\n", topics[i], qos[i]);
		}
		else
		{
			PRINTF("Failed to subscribe to the topic \"%s\" with QoS %d: %d.\r\n", topics[i], qos[i], err);
		}
	}
}
static void mqtt_subscribe_topics2(mqtt_client_t *client)
{
	static const char *topics[] = {"RicardoRedes/feeds/Subscribe_BTime"};//,"RicardoRedes/feeds/Subscribe_BTime"};
	int qos[]                   = {0};
	err_t err;
	int i;

	mqtt_set_inpub_callback(client, mqtt_incoming_publish_cb, mqtt_incoming_data_cb,
			LWIP_CONST_CAST(void *, &mqtt_client_info));

	for (i = 0; i < ARRAY_SIZE(topics); i++)
	{
		err = mqtt_subscribe(client, topics[i], qos[i], mqtt_topic_subscribed_cb, LWIP_CONST_CAST(void *, topics[i]));

		if (err == ERR_OK)
		{
			PRINTF("Subscribing to the topic \"%s\" with QoS %d...\r\n", topics[i], qos[i]);
		}
		else
		{
			PRINTF("Failed to subscribe to the topic \"%s\" with QoS %d: %d.\r\n", topics[i], qos[i], err);
		}
	}
}

/*!
 * @brief Called when connection state changes.
 */
static void mqtt_connection_cb(mqtt_client_t *client, void *arg, mqtt_connection_status_t status)
{
	const struct mqtt_connect_client_info_t *client_info = (const struct mqtt_connect_client_info_t *)arg;

	connected = (status == MQTT_CONNECT_ACCEPTED);

	switch (status)
	{
	case MQTT_CONNECT_ACCEPTED:
		PRINTF("MQTT client \"%s\" connected.\r\n", client_info->client_id);
		mqtt_subscribe_topics2(client);
		mqtt_subscribe_topics(client);
		break;

	case MQTT_CONNECT_DISCONNECTED:
		PRINTF("MQTT client \"%s\" not connected.\r\n", client_info->client_id);
		/* Try to reconnect 1 second later */
		sys_timeout(1000, connect_to_mqtt, NULL);
		break;

	case MQTT_CONNECT_TIMEOUT:
		PRINTF("MQTT client \"%s\" connection timeout.\r\n", client_info->client_id);
		/* Try again 1 second later */
		sys_timeout(1000, connect_to_mqtt, NULL);
		break;

	case MQTT_CONNECT_REFUSED_PROTOCOL_VERSION:
	case MQTT_CONNECT_REFUSED_IDENTIFIER:
	case MQTT_CONNECT_REFUSED_SERVER:
	case MQTT_CONNECT_REFUSED_USERNAME_PASS:
	case MQTT_CONNECT_REFUSED_NOT_AUTHORIZED_:
		PRINTF("MQTT client \"%s\" connection refused: %d.\r\n", client_info->client_id, (int)status);
		/* Try again 10 seconds later */
		sys_timeout(10000, connect_to_mqtt, NULL);
		break;

	default:
		PRINTF("MQTT client \"%s\" connection status: %d.\r\n", client_info->client_id, (int)status);
		/* Try again 10 seconds later */
		sys_timeout(10000, connect_to_mqtt, NULL);
		break;
	}
}

/*!
 * @brief Starts connecting to MQTT broker. To be called on tcpip_thread.
 */
static void connect_to_mqtt(void *ctx)
{
	LWIP_UNUSED_ARG(ctx);

	PRINTF("Connecting to MQTT broker at %s...\r\n", ipaddr_ntoa(&mqtt_addr));

	mqtt_client_connect(mqtt_client, &mqtt_addr, EXAMPLE_MQTT_SERVER_PORT, mqtt_connection_cb,
			LWIP_CONST_CAST(void *, &mqtt_client_info), &mqtt_client_info);
}

/*!
 * @brief Called when publish request finishes.
 */
static void mqtt_message_published_cb(void *arg, err_t err)
{
	const char *topic = (const char *)arg;

	if (err == ERR_OK)
	{
		PRINTF("Published to the topic \"%s\".\r\n", topic);
	}
	else
	{
		PRINTF("Failed to publish to the topic \"%s\": %d.\r\n", topic, err);
	}
}

/*!
 * @brief Publishes a message. To be called on tcpip_thread.
 */
void publish_message(void *ctx)
{
	static const char *topic   = "RicardoRedes/feeds/Publish_KA";
	static const char *message = "KeepAlive";

	LWIP_UNUSED_ARG(ctx);

	PRINTF("Going to publish to the topic \"%s\"...\r\n", topic);

	mqtt_publish(mqtt_client, topic, message, strlen(message), 1, 0, mqtt_message_published_cb, (void *)topic);

	static const char *topic2   = "RicardoRedes/feeds/Publish_BL";
	static const char *message2 = "BatteryLevel\r\n";
	if(1 == rx_Complete_bat){
		static const char *message2 = "BatteryLevel\r\n";

	}

	LWIP_UNUSED_ARG(ctx);

	PRINTF("Going to publish to the topic \"%s\"...\r\n", topic2);

	mqtt_publish(mqtt_client, topic2, message2, strlen(message2), 1, 0, mqtt_message_published_cb, (void *)topic2);
}

/*!
 * @brief Application thread.
 */

void RGB_init(void){
	SIM->SCGC5 = 0x400;
	/**RGB pins as GPIO*/
	PORTB->PCR[22] = 0x00000100;
	/**Assigns a safe value to RGB pins*/
	GPIOB->PSOR = 1<<22;
	/**RGB pins as output*/
	GPIOB->PDDR  = 1<<22;

}

static FLEXCAN_CALLBACK(flexcan_callback)
																{
	switch (status)
	{
	/* Process FlexCAN Rx event. */
	case kStatus_FLEXCAN_RxIdle:
		if (RX_KPA_BUFFER_NUM == result)
		{
			rx_Complete_kpa = true;
			(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_bat);
			(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_kpa);


		}
		if (RX_BAT_BUFFER_NUM == result)
		{
			rx_Complete_bat = true;
			(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_bat);
			(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_kpa);


		}
		break;

		/* Process FlexCAN Tx event. */
	case kStatus_FLEXCAN_TxIdle:
		if (TX_BAT_REPORT_BUFFER_NUM == result)
		{
			txComplete_rep_bat = true;
		}

		if (TX_ACTUADOR_BUFFER_NUM == result)
		{
			txComplete_actuador = true;
		}
		break;

	default:
		break;
	}
																}


void print_CAN_rx_message( CAN_rx_message_t can_message)
{

	LOG_INFO("\r\n");
	if( KEEP_ALIVE_ID == can_message.ID)
	{
		LOG_INFO(" 			KeepAlive ID = 0x%x\r\n", can_message.ID);

	}
	if( 0x25 == can_message.ID)
	{
		LOG_INFO(" 			Nivel de bateria. ID = 0x%x\r\n", can_message.ID);
	}


	LOG_INFO("					tx word1 = 0x%x\r\n", can_message.dataword0);
	LOG_INFO("					tx word1 = 0x%x\r\n", can_message.dataword1);

}


static void can_tx_thread(void )
{


	TickType_t xLastWakeTime;
	const TickType_t xPeriod = pdMS_TO_TICKS( 2000 );
	xLastWakeTime = xTaskGetTickCount();

	/* Setup Tx Message Buffer. */
	FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, TX_BAT_REPORT_BUFFER_NUM, true);
	FLEXCAN_SetTxMbConfig(EXAMPLE_CAN, 	TX_ACTUADOR_BUFFER_NUM, true);


	/* Prepare Tx Frame for sending. */
	txFrame_rep_bat.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
	txFrame_rep_bat.type   = (uint8_t)kFLEXCAN_FrameTypeData;
	txFrame_rep_bat.id     = FLEXCAN_ID_STD(FRECUENCIA_REPORTE_BATERIA_ID);
	txFrame_rep_bat.length = (uint8_t)DLC;

	txFrame_act.format = (uint8_t)kFLEXCAN_FrameFormatStandard;
	txFrame_act.type   = (uint8_t)kFLEXCAN_FrameTypeData;
	txFrame_act.id     = FLEXCAN_ID_STD(ACTUADOR_ID);
	txFrame_act.length = (uint8_t)DLC;


	txXfer_rep_bat.mbIdx = (uint8_t)TX_BAT_REPORT_BUFFER_NUM;
	txXfer_rep_bat.frame = & txFrame_rep_bat;


	txXfer_act.mbIdx = (uint8_t)TX_ACTUADOR_BUFFER_NUM;
	txXfer_act.frame = & txFrame_act;


	uint8_t freq_reporte_bat =  T_10s ;

	uint8_t actuador_estado =  true;


	/* Send data through Tx Message Buffer. */

	if(txComplete_actuador){


		LOG_INFO("Send message from MB%d to MB%d\r\n", TX_BAT_REPORT_BUFFER_NUM, RX_KPA_BUFFER_NUM);
		LOG_INFO("tx word0 = 0x%x\r\n",  txFrame_rep_bat.dataWord0);
		LOG_INFO("tx word1 = 0x%x\r\n",  txFrame_rep_bat.dataWord1);

		txComplete_actuador = false;
	}


}

void CAN_Control_Task(void* Args){


	CAN_rx_message_t any_rx_can_message;


	// constantly poll CAN status flas
	for(;;)
	{

		PRINTF(" on control  thread /n");
		if( 0 != Get_Elements_Count() )
		{
			Fifo_Pop(  (void * )(& any_rx_can_message), sizeof (any_rx_can_message) );
			print_CAN_rx_message(any_rx_can_message );

		}

	}
}

void can_rx_thread(void)
{

	/* Setup Rx Message Buffer. */
	mbConfig_kpa.format = kFLEXCAN_FrameFormatStandard;
	mbConfig_kpa.type   = kFLEXCAN_FrameTypeData;
	mbConfig_kpa.id     = FLEXCAN_ID_STD(KEEP_ALIVE_ID);

	mbConfig_batery.format = kFLEXCAN_FrameFormatStandard;
	mbConfig_batery.type   = kFLEXCAN_FrameTypeData;
	mbConfig_batery.id     = FLEXCAN_ID_STD(NIVEL_BATERIA_ID);


	FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_KPA_BUFFER_NUM, &mbConfig_kpa, true);
	FLEXCAN_SetRxMbConfig(EXAMPLE_CAN, RX_BAT_BUFFER_NUM, &mbConfig_batery, true);

	/* Start receive data through Rx Message Buffer. */
	rxXfer_kpa.mbIdx = (uint8_t)RX_KPA_BUFFER_NUM;
	rxXfer_kpa.frame = &rxFrame_kpa;


	rxXfer_bat.mbIdx = (uint8_t)RX_BAT_BUFFER_NUM;
	rxXfer_bat.frame = &rxFrame_bat;


	//(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_kpa);
	if(rx_Complete_kpa){
		GPIOB->PTOR = 1<<22;
		g_can_kpa_arrived = 1 ;

		can_rx_keep_alive.ID = KEEP_ALIVE_ID  ;
		can_rx_keep_alive.dataword0;// = rxFrame_kpa.dataWord0 ;
		can_rx_keep_alive.dataword1;// = rxFrame_kpa.dataWord1 ;

		Fifo_Push( (void *)(&can_rx_keep_alive), sizeof(can_rx_keep_alive));

		rx_Complete_kpa = false;
	}

	(void)FLEXCAN_TransferReceiveNonBlocking(EXAMPLE_CAN, &flexcanHandle, &rxXfer_bat);
	if(rx_Complete_bat){

		g_can_bat_arrived = 1 ;

		can_rx_nivel_bateria.ID = NIVEL_BATERIA_ID ;
		can_rx_nivel_bateria.dataword0 = rxFrame_bat.dataWord0;
		can_rx_nivel_bateria.dataword1 = rxFrame_bat.dataWord1 ;

		Fifo_Push( (void *)(&can_rx_nivel_bateria), sizeof(can_rx_nivel_bateria));

		g_can_bat_arrived = false;

		rx_Complete_bat = false ;
	}

}


static void app_thread(void *arg)
{
	struct netif *netif = (struct netif *)arg;
	struct dhcp *dhcp;
	err_t err;
	int i;

	/* Wait for address from DHCP */

	PRINTF("Getting IP address from DHCP...\r\n");

	do
	{
		if (netif_is_up(netif))
		{
			dhcp = netif_dhcp_data(netif);
		}
		else
		{
			dhcp = NULL;
		}

		sys_msleep(20U);



	} while ((dhcp == NULL) || (dhcp->state != DHCP_STATE_BOUND));

	//cada vez que recibas de MQTT el actuador  mandas a llamar RX
	can_tx_thread();


	// cada vez que recibas KPA, pubilcas.
	can_rx_thread();

	PRINTF("\r\nIPv4 Address     : %s\r\n", ipaddr_ntoa(&netif->ip_addr));
	PRINTF("IPv4 Subnet mask : %s\r\n", ipaddr_ntoa(&netif->netmask));
	PRINTF("IPv4 Gateway     : %s\r\n\r\n", ipaddr_ntoa(&netif->gw));

	/*
	 * Check if we have an IP address or host name string configured.
	 * Could just call netconn_gethostbyname() on both IP address or host name,
	 * but we want to print some info if goint to resolve it.
	 */
	if (ipaddr_aton(EXAMPLE_MQTT_SERVER_HOST, &mqtt_addr) && IP_IS_V4(&mqtt_addr))
	{
		/* Already an IP address */
		err = ERR_OK;
	}
	else
	{
		/* Resolve MQTT broker's host name to an IP address */
		PRINTF("Resolving \"%s\"...\r\n", EXAMPLE_MQTT_SERVER_HOST);
		err = netconn_gethostbyname(EXAMPLE_MQTT_SERVER_HOST, &mqtt_addr);
	}

	if (err == ERR_OK)
	{
		/* Start connecting to MQTT broker from tcpip_thread */
		err = tcpip_callback(connect_to_mqtt, NULL);
		if (err != ERR_OK)
		{
			PRINTF("Failed to invoke broker connection on the tcpip_thread: %d.\r\n", err);
		}
	}
	else
	{
		PRINTF("Failed to obtain IP address: %d.\r\n", err);
	}

	/* Publish some messages */
	for (i = 0; i < 1;)
	{
		if (connected)
		{
			err = tcpip_callback(publish_message, NULL);
			if (err != ERR_OK)
			{
				PRINTF("Failed to invoke publishing of a message on the tcpip_thread: %d.\r\n", err);
			}
			i++;
		}

		sys_msleep(1000U);
	}

	vTaskDelete(NULL);
}

static void generate_client_id(void)
{
	uint32_t mqtt_id[MQTT_ID_SIZE];
	int res;

	get_mqtt_id(&mqtt_id[0]);

	res = snprintf(client_id, sizeof(client_id), "nxp_%08lx%08lx%08lx%08lx", mqtt_id[3], mqtt_id[2], mqtt_id[1],
			mqtt_id[0]);
	if ((res < 0) || (res >= sizeof(client_id)))
	{
		PRINTF("snprintf failed: %d\r\n", res);
		while (1)
		{
		}
	}
}

/*!
 * @brief Initializes lwIP stack.
 *
 * @param arg unused
 */
static void stack_init(void *arg)
{
	static struct netif netif;
	ip4_addr_t netif_ipaddr, netif_netmask, netif_gw;
	ethernetif_config_t enet_config = {
			.phyHandle  = &phyHandle,
			.macAddress = configMAC_ADDR,
	};

	LWIP_UNUSED_ARG(arg);
	generate_client_id();

	mdioHandle.resource.csrClock_Hz = EXAMPLE_CLOCK_FREQ;

	IP4_ADDR(&netif_ipaddr, 0U, 0U, 0U, 0U);
	IP4_ADDR(&netif_netmask, 0U, 0U, 0U, 0U);
	IP4_ADDR(&netif_gw, 0U, 0U, 0U, 0U);

	tcpip_init(NULL, NULL);

	LOCK_TCPIP_CORE();
	mqtt_client = mqtt_client_new();
	UNLOCK_TCPIP_CORE();
	if (mqtt_client == NULL)
	{
		PRINTF("mqtt_client_new() failed.\r\n");
		while (1)
		{
		}
	}

	netifapi_netif_add(&netif, &netif_ipaddr, &netif_netmask, &netif_gw, &enet_config, EXAMPLE_NETIF_INIT_FN,
			tcpip_input);
	netifapi_netif_set_default(&netif);
	netifapi_netif_set_up(&netif);

	netifapi_dhcp_start(&netif);

	PRINTF("\r\n************************************************\r\n");
	PRINTF(" MQTT client example\r\n");
	PRINTF("************************************************\r\n");

	if (sys_thread_new("app_task", app_thread, &netif, APP_THREAD_STACKSIZE, APP_THREAD_PRIO) == NULL)
	{
		LWIP_ASSERT("stack_init(): Task creation failed.", 0);
	}



	vTaskDelete(NULL);
}

int EsComando(char *Comando,char *Const){
	int iguales=1;
	int contador=0;
	do{
		if(*Const==*Comando){
			Comando++;
			Const++;
			contador++;

		}else{
			iguales=0;
			break;
		}
	}while(*Const != '\0');

return iguales;
}

/*!
 * @brief Main function
 */
int main(void)
{
	flexcan_config_t flexcanConfig;

	SYSMPU_Type *base = SYSMPU;
	SIM->SCGC5 = 0x400;
	/**RGB pins as GPIO*/
	//PORTB->PCR[22] = 0x00000100;
	/**Assigns a safe value to RGB pins*/
	//GPIOB->PSOR = 1<<22;
	/**RGB pins as output*/
	//GPIOB->PDDR  = 1<<22;

	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitDebugConsole();
	/* Disable SYSMPU. */
	base->CESR &= ~SYSMPU_CESR_VLD_MASK;


	/** init CAN * */

	LOG_INFO("\r\n==FlexCAN loopback example -- Start.==\r\n\r\n");

	FLEXCAN_GetDefaultConfig(&flexcanConfig);

#if defined(EXAMPLE_CAN_CLK_SOURCE)
	flexcanConfig.clkSrc = EXAMPLE_CAN_CLK_SOURCE;
#endif

	flexcanConfig.enableLoopBack = false;
	flexcanConfig.baudRate               = 125000U;

	FLEXCAN_Init(EXAMPLE_CAN, &flexcanConfig, EXAMPLE_CAN_CLK_FREQ);

	/* Create FlexCAN handle structure and set call back function. */
	FLEXCAN_TransferCreateHandle(EXAMPLE_CAN, &flexcanHandle, flexcan_callback, NULL);


	/** do FIFO init of  3 KB */
	Init_FIFO( 1024*3);

	/** init status LED */
	//RGB_init();

	/* Initialize lwIP from thread */
	if (sys_thread_new("main", stack_init, NULL, INIT_THREAD_STACKSIZE, INIT_THREAD_PRIO) == NULL)
	{
		LWIP_ASSERT("main(): Task creation failed.", 0);
	}

	//if (sys_thread_new("CAN_RX", can_rx_thread,NULL, APP_THREAD_STACKSIZE, 4) == NULL)
	//{
	//		LWIP_ASSERT("stack_init(): Task creation failed.", 0);
	//}

	//	if (sys_thread_new("CAN_TX", can_tx_thread, NULL, APP_THREAD_STACKSIZE, 3) == NULL)
	//	{
	//		LWIP_ASSERT("stack_init(): Task creation failed.", 0);
	//	}


	//	if (sys_thread_new("CAN_Control_Task", CAN_Control_Task, NULL, APP_THREAD_STACKSIZE, 3) == NULL)
	//	{
	//		LWIP_ASSERT("stack_init(): Task creation failed.", 0);
	//	}
	vTaskStartScheduler();

	/* Will not get here unless a task calls vTaskEndScheduler ()*/
	return 0;
}
#endif
